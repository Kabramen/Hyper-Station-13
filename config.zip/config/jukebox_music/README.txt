The enclosed sounds folder holds the sound files used as player selectable songs for an ingame jukebox. OGG and WAV are supported.

Using unnecessarily huge sounds can cause client side lag and should be avoided.

You my add as many sounds as you would like.

---

Naming Conventions:

Every sound you add must have a unique name. Avoid using the plus sign "+" and the period "." in names, as these are used internally to classify sounds.

Sound names must be in the format of [song name]+[length in deciseconds]+[beat in deciseconds].ogg

A three minute song title "SS13" that lasted 3 minutes would have a file name SS13+1800+5.ogg